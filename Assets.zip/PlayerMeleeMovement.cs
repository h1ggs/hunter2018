﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMeleeMovement : MonoBehaviour {

	private Transform t;
	private PlayerGunMovement pgm;
	public PlayerMovement pm;

	void Awake(){
		pgm = GetComponent<PlayerGunMovement> ();
		pm = GetComponent<PlayerMovement> ();
	}
	void Start () {
		t = GetComponent<Transform> ();
		pgm.enabled = false;
	}

	// Update is called once per frame
	void Update () {

		float inputHorizontal = Input.GetAxisRaw ("Horizontal");
		float inputVertical = Input.GetAxisRaw ("Vertical");

		if (inputHorizontal > 0) {
			t.eulerAngles = new Vector3 (t.eulerAngles.x, 0, t.eulerAngles.z);
		} else if (inputHorizontal < 0) {
			t.eulerAngles = new Vector3 (t.eulerAngles.x, 180, t.eulerAngles.z);
		}
	}
}
