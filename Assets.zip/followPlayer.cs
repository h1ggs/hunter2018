﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class followPlayer : MonoBehaviour {

	public float min;
	public float max;

	public bool trigEnter = false;
	public bool trigExit = false;

	public Transform tracker;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		Vector3 newpos = this.transform.position;
		Vector3 playerPos = GameObject.Find ("Player").transform.position;
		if (trigEnter == true) {



			if (newpos.x < min) {
				this.transform.position = new Vector3 ((newpos.x), transform.position.y, transform.position.z);
				Debug.Log (trigExit);
			}



		} else if (trigEnter == false) {
			this.transform.position = this.transform.position;
		}
	}

}


