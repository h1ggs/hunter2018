﻿using UnityEngine; 
using System.Collections;


public class AnimalMovement : MonoBehaviour {


	public float walkSpeed = 0;
	public float wallLeft = 0.0f;
	public float wallRight = 5.0f;
	float walkingDirection = 1.0f;
	Vector3 walkAmount;

	private Animator anim;
	private Animation animation;
	private Vector3 ls;

	void Start(){
		anim = this.GetComponent<Animator> ();
		ls = this.GetComponentInParent<Transform> ().localScale; 
	}

	// Update is called once per frame
	void Update () {

		walkAmount.x = walkingDirection * walkSpeed * Time.deltaTime;

		if (transform.position.x == wallRight) {

		}


		if (walkingDirection > 0.0f && transform.position.x >= wallRight) {
			walkingDirection = -1.0f;
			StartCoroutine (Eat (false));
		}
		else if (walkingDirection < 0.0f && transform.position.x <= wallLeft){
			walkingDirection = 1.0f;
			StartCoroutine (Eat (true));
		}
		transform.Translate(walkAmount);
	}
		
	IEnumerator Eat(bool flip){
		walkSpeed = 0;
		anim.SetBool ("DeerWalk", true);
		yield return new WaitForSeconds (1);

		if(flip == true){
			Vector3 temp = this.GetComponentInParent<Transform> ().localScale;
			temp.x = -1;

			this.GetComponentInParent<Transform> ().localScale = temp;
		} else {
			Vector3 temp = this.GetComponentInParent<Transform> ().localScale;
			temp.x = 1;

			this.GetComponentInParent<Transform> ().localScale = temp;
		}

		anim.SetBool ("DeerWalk", false);
		walkSpeed = 2;
	}

} 

