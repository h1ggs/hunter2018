﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damageable : MonoBehaviour {

	public enemyScript parentObj;
	public int damageAmount;

	void Awake(){

	}

	// Use this for initialization
	void Start () {
		parentObj = this.GetComponentInParent<enemyScript> ();
	}

	public void sendDamageToParent(){
		parentObj.takeDamage (damageAmount);
		Debug.Log ("Send");
	}
		


}