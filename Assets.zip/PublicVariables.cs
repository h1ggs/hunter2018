﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PublicVariables : MonoBehaviour {

	public bool flipSprite = false;
	public bool axeChop = false;
	public int numAxeChops = 0;
	public bool objectHit = false;
	public bool hasGunRight;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
