﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class MeleeController : MonoBehaviour {

	public GameObject Player2;
	private Animator anim;
	private PublicVariables pubVar;
	public bool axeChop;
	public float chopTimeOffset;
	public UnityEvent doWhenAttack;
	private float timer = 1;
	public int damage;
	public treeBehavior tB;
	private Collider2D wepCollider;
	private PlayerMeleeMovement pmm;

	void Awake(){
		//Player2.transform.localScale = new Vector2 (transform.localScale.x, transform.localScale.y);
		wepCollider = GetComponent<Collider2D> ();
		Player2 = GameObject.Find ("Player");
	}

	void Start(){


		anim = Player2.GetComponent<Animator> ();
		pubVar = GameObject.Find ("_GM").GetComponent<PublicVariables> ();
		//ArmsGuy = GameObject.Find ("Arms").GetComponent<SpriteRenderer> ();
		tB = GameObject.Find ("ChopTree").GetComponent<treeBehavior> ();
		pmm = Player2.GetComponent<PlayerMeleeMovement> ();
		anim.SetBool ("AxeIdle", true);
		anim.SetLayerWeight (1, 1);
		anim.SetLayerWeight (2, 0);


		wepCollider.enabled = false;

		pmm.enabled = true;
	}

	void Update(){
		if (Input.GetKeyDown (KeyCode.Mouse0)) {
			anim.SetBool ("AxeChop", true);
			wepCollider.enabled = true;
			pmm.pm.enabled = false;
		} 

		if (Input.GetKey (KeyCode.Mouse0)) {
			anim.SetBool ("AxeChop", true);
			wepCollider.enabled = true;
		} 

		if (Input.GetKeyUp (KeyCode.Mouse0)) {
			anim.SetBool ("AxeChop", false);
			wepCollider.enabled = false;
			pmm.pm.enabled = true;
		}

		if (pubVar.flipSprite == true) {
			Player2.transform.localScale = new Vector2 (-transform.localScale.x, transform.localScale.y);
			//ArmsGuy.flipX = true;
		} else {
			Player2.transform.localScale = new Vector2 (transform.localScale.x, transform.localScale.y);
			//ArmsGuy.flipX = false;
		}

		timer += Time.deltaTime;

		if (timer >= chopTimeOffset && anim.GetBool ("AxeChop") == true) {
			//StartCoroutine (swingAxe (chopTimeOffset));
			doChop();
			timer = 0;
		}

	}

	void OnTriggerEnter2D(Collider2D other){

		GameObject objectCollided = other.gameObject;
		Damageable damageableComponent = objectCollided.GetComponent<Damageable> ();

		if (damageableComponent) {
			//damageableComponent.doDamage (damage);
		}
	}

	public void doChop(){
		tB.choppedNow ();
	}

	private IEnumerator swingAxe(float chopTimeOffset){
		yield return new WaitForSeconds(chopTimeOffset);
		tB.choppedNow ();
	}

	void OnDestroy(){
		Player2.transform.localScale = new Vector2 (transform.localScale.x, transform.localScale.y);
		pmm.enabled = false;
	}
}
