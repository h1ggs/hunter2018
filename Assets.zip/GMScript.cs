﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GMScript : MonoBehaviour {

	public static GMScript instance = null;
	public int playerFoodPoints = 100;
	[HideInInspector] public bool playersTurn = true;

	public Vector3 mousePosition;

	private int level = 3;

	void Awake(){

		if (instance == null)
			instance = this;
		else if (instance != this)
			Destroy (gameObject);

		DontDestroyOnLoad (gameObject);

		InitGame ();
	
	}

	void InitGame(){

	}

	void Update(){
		mousePosition = new Vector3(Camera.main.ScreenToWorldPoint(Input.mousePosition).x, Camera.main.ScreenToWorldPoint(Input.mousePosition).y,0);
	}



	public void GameOver(){

	}

	// Use this for initialization
	void Start () {
		enabled = false;
	}

}
