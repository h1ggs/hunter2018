﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EyeDoorTrack : MonoBehaviour {

	public GameObject eye;

	void OnTriggerEnter2D (Collider2D other){
		if (other.gameObject.tag == "Player") {
			eye.GetComponent<followPlayer> ().trigEnter = true;
		}
	}
	void OnTriggerExit2D(Collider2D other)
	{
		if (other.gameObject.tag == "Player") {
			eye.GetComponent<followPlayer> ().trigEnter = false;
		}
	}
}
