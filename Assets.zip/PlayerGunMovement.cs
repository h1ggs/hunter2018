﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerGunMovement : MonoBehaviour {

	public PublicVariables pubVar;
	private Transform t;
	private PlayerMeleeMovement pmm;

	void Awake(){
		pmm = GetComponent<PlayerMeleeMovement> ();
	}

	void Start () {
		t = GetComponent<Transform> ();
		pubVar = GameObject.Find ("_GM").GetComponent<PublicVariables> ();
		pmm.enabled = false;

	}
	
	// Update is called once per frame
	void Update () {

		float inputHorizontal = Input.GetAxisRaw ("Horizontal");
		float inputVertical = Input.GetAxisRaw ("Vertical");

		if (inputHorizontal > 0 && pubVar.hasGunRight == true) {
			t.eulerAngles = new Vector3 (t.eulerAngles.x, 0, t.eulerAngles.z);
		} else if (inputHorizontal < 0 && pubVar.hasGunRight == false) {
			t.eulerAngles = new Vector3 (t.eulerAngles.x, 180, t.eulerAngles.z);
		}

		if (pubVar.hasGunRight == false && Input.GetAxisRaw ("Horizontal") == 0) {
			t.eulerAngles = new Vector3 (t.eulerAngles.x, 180, t.eulerAngles.z); 
		} else if (pubVar.hasGunRight == true && Input.GetAxisRaw ("Horizontal") == 0) {
			t.eulerAngles = new Vector3 (t.eulerAngles.x, 0, t.eulerAngles.z); 
		}
	}
}
