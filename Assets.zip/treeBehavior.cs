﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class treeBehavior : MonoBehaviour {

	private Animator anim;
	private PublicVariables pubVar;
	private bool isChopable = false;
	private int treeHits;
	public int hitsNeededtoSpawn;
	private Animator treeAnim;
	public GameObject woodPileSpawn;
	public GameObject woodPile;
	public bool objectHit;

	// Use this for initialization
	void Start () {
		treeAnim = GetComponent<Animator> ();
		anim = GameObject.Find ("Player").GetComponent<Animator> (); 
		pubVar = GameObject.Find ("_GM").GetComponent<PublicVariables> ();
		woodPile = Resources.Load ("Sprites/Items/wood") as GameObject;
		//woodPileSpawn = this.gameObject.GetComponentInChildren<GameObject> ();
	}
	
	void Update(){
		if (treeHits == hitsNeededtoSpawn && isChopable == true) {

			treeHits = 0;

			Instantiate (woodPile, woodPileSpawn.transform.position, Quaternion.identity, this.transform);
		}
			
	}
		
	void doTreeHitAnimation(){

	}

	void doDamage(){
		if (isChopable == true) {
			treeHits++;
		}
		StopCoroutine (doChopDmg ());
	}

	void OnTriggerStay2D(Collider2D other) {
		if (other.gameObject.tag == "Axe") {
			isChopable = true;
			if (objectHit == true) {
				treeAnim.SetTrigger ("treeHit");
			}
		}
	}

	void OnTriggerExit2D(Collider2D other){
		if (other.gameObject.tag == "Axe") {
			isChopable = false;

		}
	}

	private IEnumerator doChopDmg(){
		doDamage ();
		yield return new WaitForSeconds(2);


	}

	public void choppedNow(){
		if (isChopable == true) {
			pubVar.axeChop = true;
		}
		StartCoroutine (doChopDmg ());;
	}
}
