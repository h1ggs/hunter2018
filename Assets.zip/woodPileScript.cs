﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class woodPileScript : MonoBehaviour {

	private Rigidbody2D rb;
	public float min;
	public float max;
	// Use this for initialization

	void Awake(){
		rb = GetComponent<Rigidbody2D> ();
	}

	void Start () {
		rb.AddForce (new Vector2 (min, max));
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
