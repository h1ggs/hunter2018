﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class mouseToggle : MonoBehaviour, ICanvasRaycastFilter {

	public bool interactable;
	public bool toggle;
	public Inventory slotPanel;
	int sizeOfList;
	int alpha;


	void Start () {
		interactable = false;
		Cursor.visible = false;



		for (int i = 1; i < sizeOfList; i++){
			slotPanel.slots [i].GetComponent<Image> ().color = new Color32 (255, 255, 255, 128);
		}

	}

	// Update is called once per frame
	void Update () {
		sizeOfList = slotPanel.slots.Count;

		if (Input.GetKeyDown (KeyCode.Tab) && interactable == false) {
			interactable = true;

			for (int i = 0; i < sizeOfList; i++){
				slotPanel.slots [i].GetComponent<Image> ().color = new Color32 (255, 255, 255, 255);
			}

			Cursor.visible = true;

		} else if (Input.GetKeyDown (KeyCode.Tab) && interactable == true) {
			interactable = false;
			for (int i = 0; i < sizeOfList; i++){
				slotPanel.slots [i].GetComponent<Image> ().color = new Color32 (255, 255, 255, 128);
			}
			Cursor.visible = false;
		}

	}
	void OnTriggerStay2D (Collider2D other){

	}

	public bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera){
		if (interactable == true) {
			return true;
		} else  {
			return false;
		}



	}
}