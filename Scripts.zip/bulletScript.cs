﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class bulletScript : MonoBehaviour {

	public Rigidbody2D rb;
	public float thrust;
	//public GameObject target;
	public float dropBulletTime;
	private Vector3 mp;
	public ParticleSystem ps;

	void Awake(){
	}

	// Use this for initialization
	void Start () {

		//Subtract the bullet's transform from the muzzleEnd, then normalize and multiply thrust.
		rb = GetComponent<Rigidbody2D> ();

		Vector3 crosshairLocation = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		crosshairLocation.z = 0;

		rb.AddForce ((crosshairLocation - transform.position).normalized *  thrust);
		StartCoroutine (changeGravityBullet ());


		//target.transform.position = Camera.main.ScreenToWorldPoint (Input.mousePosition);

	}

	// Update is called once per frame
	void Update () {



		//float step = thrust * Time.deltaTime;
		//transform.position = Vector2.MoveTowards (transform.position, target.transform.position, step);
		//GameObject.Find("Gun").GetComponent<gunController>().get


	}

	void FixedUpdate(){


		//transform.right = rb.velocity;

	}

	public IEnumerator changeGravityBullet(){

		rb.gravityScale = 0;
		yield return new WaitForSeconds (dropBulletTime);
		rb.gravityScale = 2;

	}

	void OnCollisionEnter2D(Collision2D collisionInfo){


		if (collisionInfo.gameObject.tag.Equals("Enemy")) {
			collisionInfo.gameObject.GetComponent<enemyScript> ().takeDamage (1);

			//Debug.Log(collisionInfo.collider.name);
		}

		if (collisionInfo != null) {
			ContactPoint2D contact = collisionInfo.contacts [0];
			Quaternion rot = Quaternion.FromToRotation (Vector3.up, contact.normal);
			Vector3 pos = contact.point;
			Instantiate (ps, pos, rot);
		}
		//Instantiate (ps);
		Destroy (this.gameObject);


	}


}