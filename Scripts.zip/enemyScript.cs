﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class enemyScript : MonoBehaviour {

	[SerializeField] private float enemyHP = 10f; 

	public GameObject[] bodyParts;


	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		if (enemyHP <= 0) {
			DestroyObject (this.gameObject);
		}

	}

	public void takeDamage (int dmg){
		enemyHP = enemyHP - dmg;
		Debug.Log ("taking dmg");
	}
		
}