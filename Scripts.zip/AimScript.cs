﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimScript : MonoBehaviour {

	private float someScale;
	private float location;
	private SpriteRenderer flipChar;
	public float offsetPos;

	public float offset;


	// Use this for initialization
	void Start () {
		someScale = transform.localScale.y;
		location = transform.position.x;
		flipChar = GameObject.Find ("Player").GetComponent<SpriteRenderer> ();
	}

	// Update is called once per frame
	void Update () {

		Vector3 dir = Input.mousePosition - Camera.main.WorldToScreenPoint (transform.position);
		aimGun (dir);
	}

	void aimGun(Vector3 dir){

		//This aims the gun
		float angle = Mathf.Atan2 (dir.y, dir.x) * Mathf.Rad2Deg;
		gameObject.transform.localRotation = Quaternion.AngleAxis ((angle + offset), Vector3.forward);

		if (gameObject.transform.eulerAngles.z < 360 && gameObject.transform.eulerAngles.z > 270) {
			//Debug.Log ("greater than -90, less than zero");
		}

		if (gameObject.transform.eulerAngles.z < 90 || gameObject.transform.eulerAngles.z < 360 && gameObject.transform.eulerAngles.z > 270 ) {
			gameObject.transform.localScale = new Vector2 (gameObject.transform.localScale.x, someScale);
			flipChar.flipX = false;
		} else {
			gameObject.transform.localScale = new Vector2 (gameObject.transform.localScale.x, -someScale);
			//gameObject.transform.position = new Vector2 (location - offsetPos, gameObject.transform.position.y);
			flipChar.flipX = true;
		}

	}
}
